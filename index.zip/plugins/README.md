# Plugins

This directory contains all the bot plugins.
