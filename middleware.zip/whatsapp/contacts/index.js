// Contacts module barrel export
export { ContactManager, getContactManager } from './manager.js'
export { ContactResolver, getContactResolver } from './resolver.js'